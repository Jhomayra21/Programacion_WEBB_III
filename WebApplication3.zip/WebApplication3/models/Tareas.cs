﻿namespace WebApplication3.models
{
    public class Tarea
    {
        public string idTarea { get; set; }
        public string nombreTarea { get; set; }
        public string fechaVencimiento { get; set; }
        public string estado { get; set; }
    }
}
